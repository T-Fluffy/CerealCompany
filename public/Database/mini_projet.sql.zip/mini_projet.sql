-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 07, 2024 at 06:42 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mini_projet`
--

-- --------------------------------------------------------

--
-- Table structure for table `cereale`
--

CREATE TABLE `cereale` (
  `id` int(11) NOT NULL,
  `nom_c` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prix` int(11) NOT NULL,
  `code_c` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cereale`
--

INSERT INTO `cereale` (`id`, `nom_c`, `prix`, `code_c`) VALUES
(3, 'grain dor', 200, 12165);

-- --------------------------------------------------------

--
-- Table structure for table `collecte`
--

CREATE TABLE `collecte` (
  `id` int(11) NOT NULL,
  `code_c_id` int(11) NOT NULL,
  `code_s_id` int(11) NOT NULL,
  `date_c` date NOT NULL,
  `quantite` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `doctrine_migration_versions`
--

CREATE TABLE `doctrine_migration_versions` (
  `version` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `executed_at` datetime DEFAULT NULL,
  `execution_time` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `doctrine_migration_versions`
--

INSERT INTO `doctrine_migration_versions` (`version`, `executed_at`, `execution_time`) VALUES
('DoctrineMigrations\\Version20211129134204', '2021-11-29 14:42:12', 145),
('DoctrineMigrations\\Version20211212161114', '2021-12-12 17:11:24', 52);

-- --------------------------------------------------------

--
-- Table structure for table `silo`
--

CREATE TABLE `silo` (
  `id` int(11) NOT NULL,
  `nom` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `adresse` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `capacite` int(11) NOT NULL,
  `code_s` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `email` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `roles` longtext COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '(DC2Type:json)',
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `email`, `roles`, `password`) VALUES
(5, 'halloultarek1@gmail.com', '[\"ROLE_ADMIN\"]', '$2y$13$SanmgRA066nFjOUnE.Wmp.GCS8JTH0yGqUOczie4Q4X/LODDQs4qC'),
(6, 'john@john.us', '[]', '$2y$13$mJN/tdbMPW6bkB6Vca.7NeRDR5FPmltACUWJphrd3jdE2Ip2gaWy2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cereale`
--
ALTER TABLE `cereale`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `collecte`
--
ALTER TABLE `collecte`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_55AE4A3DA73CF112` (`code_c_id`),
  ADD KEY `IDX_55AE4A3DF725A68D` (`code_s_id`);

--
-- Indexes for table `doctrine_migration_versions`
--
ALTER TABLE `doctrine_migration_versions`
  ADD PRIMARY KEY (`version`);

--
-- Indexes for table `silo`
--
ALTER TABLE `silo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_8D93D649E7927C74` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cereale`
--
ALTER TABLE `cereale`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `collecte`
--
ALTER TABLE `collecte`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `silo`
--
ALTER TABLE `silo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `collecte`
--
ALTER TABLE `collecte`
  ADD CONSTRAINT `FK_55AE4A3DA73CF112` FOREIGN KEY (`code_c_id`) REFERENCES `cereale` (`id`),
  ADD CONSTRAINT `FK_55AE4A3DF725A68D` FOREIGN KEY (`code_s_id`) REFERENCES `silo` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
